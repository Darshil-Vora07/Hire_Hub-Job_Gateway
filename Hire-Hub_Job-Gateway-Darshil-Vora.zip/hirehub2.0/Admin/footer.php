<!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">

      <div class="container">

        <div class="row  justify-content-center">
          <div class="col-lg-6">
            <h3>Created By</h3>
         <p>Dhairya patel</p>
          </div>
        </div>
      </div>
    </div>


  </footer><!-- End Footer -->
