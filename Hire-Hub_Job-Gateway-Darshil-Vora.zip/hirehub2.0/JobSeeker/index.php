<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<link href="../assets/img/favicon.ico" type="image/x-icon" rel="icon" >
<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
<?php 
include "Header.php"
?> 
<section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Welcome <?php echo $_SESSION['$UserName_job'] ;?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<section class="inner-page">
      <div class="container">
        <div class="row">
            <div class="col-sm"><div align="center"><img src="design/Profile.png" alt="" width="64" height="64" /></div></div>
			<div class="col-sm"><div align="center"><img src="design/Edu.png" alt="" width="64" height="64" /></div></div>
			<div class="col-sm"><div align="center"><img src="design/Search.png" alt="" width="64" height="64" /></div></div>
        </div>
        <div class="row">
			<div class="col-sm"><div align="center"><a href="Profile.php">Profile</a></div></div>
			<div class="col-sm"><div align="center"><a href="Education.php">Education</a></div></div>
			<div class="col-sm"><div align="center"><a href="SearchJob.php">Search JOB</a></div></div>
        </div>
				  <br><br>          
        <div class="row">
            <div class="col-sm"><div align="center"><img src="design/Interview.png" alt="" width="64" height="64" /></div></div>
			<div class="col-sm"><div align="center"><img src="design/Feedback.png" alt="" width="64" height="64" /></div></div>
			<div class="col-sm"><div align="center"><img src="design/Log.png" alt="" width="64" height="64" /></div></div>
        </div>          
        <div class="row">
			<div class="col-sm"><div align="center"><a href="Walkin.php">Walkin</a></div></div>
			<div class="col-sm"><div align="center"><a href="Feedback.php">Feedback</a></div></div>
			<div class="col-sm"><div align="center"><a href="session_destroy.php">Logout</a></div></div>
        </div>          
                 
          </div> <!-- /article -->

          </section>
            
        </div> <!-- /content -->


 
<?php
include "footer.php"
?>
</div> <!-- /main -->

</body>
</html>
