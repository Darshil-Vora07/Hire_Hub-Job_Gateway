<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<link href="../assets/img/favicon.ico" type="image/x-icon" rel="icon" >
<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
<?php 
include "Header.php"
?> 
<section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Welcome <?php echo $_SESSION['$UserName_job'] ;?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<section class="inner-page">
      <div class="container">
<?php
$ID=$_SESSION['ID'];
// Establish Connection with Database
$con = mysqli_connect("localhost","root","","job");
// Specify the query to execute
$sql = "select * from jobseeker_reg where JobSeekId='".$ID."'  ";
// Execute query
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
// Loop through each records 
$row = mysqli_fetch_array($result)
?>
                <table width="100%" border="1" cellspacing="2" cellpadding="2">
                  <tr>
                    <td><strong>Name:</strong></td>
                    <td><?php echo $row['JobSeekerName'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Address:</strong></td>
                    <td><?php echo $row['Address'];?></td>
                  </tr>
                  <tr>
                    <td><strong>City:</strong></td>
                    <td><?php echo $row['City'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Email:</strong></td>
                    <td><?php echo $row['Email'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Mobile:</strong></td>
                    <td><?php echo $row['Mobile'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Highest Qualification:</strong></td>
                    <td><?php echo $row['Qualification'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Gender:</strong></td>
                    <td><?php echo $row['Gender'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Birth Date:</strong></td>
                    <td><?php echo $row['BirthDate'];?></td>
                  </tr>
                 
                  <tr>
                    <td>&nbsp;</td>
                    <td><a href="#" data-toggle="modal" data-target="#Edit1">Edit Profile</a></td>
                  </tr>
                </table>
             

           
          </div> <!-- /article -->
</section>
            <?php
            mysqli_close($con);
            ?>

           
            
        </div> <!-- /content -->



    </div> <!-- /page-in -->
    </div> <!-- /page -->

 
<?php
include "footer.php"
?>
</div> <!-- /main -->

<div class="modal fade" id="Edit1" tabindex="-1" role="dialog" aria-labelledby="jobseekerLabel" aria-hidden="true">
<div class="modal-dialog modal-lg" role="document">
 <div class="modal-content">
 <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Profile</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
</div>
                <form action="update.php" method="post" onSubmit="return validateForm(this,arrFormValidation);" enctype="multipart/form-data" id="form2" style="margin:10px">
                    <div class="form-group">
					<input type="hidden" id="Id" name="Id" value="<?php echo $row['JobSeekId']; ?>"
					<label for="txtName">Name</label>
                        <input type="text" name="txtName" id="txtName" class="form-control" id="exampleFormControlInput1" value="<?php echo $row['JobSeekerName']; ?>" placeholder="Name"/ required>
                    </div>
                   
                    <div class="form-group">
						<label for="txtAddress">Address</label>
                        <textarea name="txtAddress" id="txtAddress" class="form-control" cols="45" rows="5"  placeholder="Address" required><?php echo $row['Address'];?></textarea>
					</div>
                      
					<div class="form-group">
                        <label for="txtCity">City</label>
                        <input type="text" class="form-control" name="txtCity" value="<?php echo $row['City'];?>" id="txtCity"  placeholder="City" required />
                     </div>
					<div class="form-group">
                        <label for="txtEmail">Email</label>
                        <input type="email" class="form-control" name="txtEmail"  value="<?php echo $row['Email'];?>" id="txtEmail"  placeholder="Email" required/>
                     </div>
                    <div class="form-group">
                        <label for="txtMobile">Mobile</label>
                        <input type="tel" minlength="9" maxlength="14" class="form-control" value="<?php echo $row['Mobile'];?>" name="txtMobile" id="txtMobile" placeholder="Phone.no" required />
                     </div>  
                      <div class="form-group">
                        <label for="txtQualification">Qualification</label>
                        <input type="text" class="form-control" name="txtQualification" id="txtQualification" value="<?php echo $row['Qualification'];?>" placeholder="Qulification" required />
                     </div>
					  <div class="form-group">
                        <label for="txtBirthDate">BirthDate</label>
                        <input type="date" value="<?php echo $row['BirthDate'];?>" class="form-control" name="txtBirthDate" id="txtBirthDate" required />
                     </div> 
					</script>
					<div class="form-group">
                        <label for="txtUserName">User Name</label>
                        <input type="text" class="form-control" name="txtUserName" value="<?php echo $row['UserName'];?>" id="txtUserName" placeholder="User Name" required />
                    </div>   
					<div class="form-group">
                        <label for="txtPassword">Password</label>
                        <input type="password" class="form-control" name="txtPassword" value="<?php echo $row['Password'];?>" id="txtPassword" placeholder="Password" required />
                    </div> 
                        <div class="modal-footer">
						  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <input type="submit" name="button2" id="button2" class="btn btn-primary" value="Submit" />
                          </div>
                      
                 </form>
				 <!-- Button trigger modal -->
</div>
</div>
</div>

</body>
</html>
