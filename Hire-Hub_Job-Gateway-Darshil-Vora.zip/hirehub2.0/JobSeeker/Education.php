<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<link href="../assets/img/favicon.ico" type="image/x-icon" rel="icon" >
<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
<?php 
include "Header.php"
?>
<section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Welcome <?php echo $_SESSION['$UserName_job'] ;?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<section class="inner-page">
      <div class="container">
               

              <table width="100%" border="1" cellspacing="2" cellpadding="2">
                  <tr>
                    <td colspan="2" bgcolor="#A0B9F3"><strong>Create Educational Profile</strong></td>
                  </tr>
				  
                  <tr>
                    <td><form id="form1" method="post" action="InsertEdu.php">
                        <tr>
                          <td><strong>Degree:</strong></td>
                          <td>
                          <input type="text" name="cmbQual" id="cmbQual">
                          
                          </td>
                        </tr>
                        
                        <tr>
                          <td><strong>University/Board Name:</strong></td>
                          <td><span id="sprytextfield1">
                            <label>
                            <input type="text" name="txtBoard" id="txtBoard" />
                            </label>
                          </span></td>
                        </tr>
                        <tr>
                          <td><strong>Passing Year:</strong></td>
                          <td><label>
                        <input type="month" name="cmbYear" id="cmbYear">
                          </label></td>
                        </tr>
                        <tr>
                          <td><strong>Percentage(%)</strong></td>
                          <td><span id="sprytextfield2">
                            <label>
                            <input type="text" name="txtPer" id="txtPer" />
                            </label>
                          </span></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td><label>
                            <input type="submit" name="button" id="button" value="Submit" />
                          </label></td>
                        </tr>
                      <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                     </form>
                    </td>
                  </tr>
				   </table>
			 
</div></section>

<section class="inner-page">
      <div class="container">
<table width="100%" border="1" cellspacing="2" cellpadding="2">
                  <tr>
                    <td colspan="4"  bgcolor="#A0B9F3"><strong>Educational Profile</strong></td>
                  </tr>
                  <tr>
                    <td>
                      <tr>
                        <th height="32" bgcolor="#006699" class="style3"><div align="left" class="style9 style5 style2"><strong>Degree</strong></div></th>
                        <th bgcolor="#006699" class="style3"><div align="left" class="style9 style5 style2"><strong>University</strong></div></th>
                        <th bgcolor="#006699" class="style3"><div align="left" class="style9 style5 style2"><strong>Passing Year</strong></div></th>
                         <th bgcolor="#006699" class="style3"><div align="left" class="style9 style5 style2"><strong>Percentage</strong></div></th>
                      </tr>
                      <?php
					  $ID=$_SESSION['ID'];
// Establish Connection with Database
$con = mysqli_connect("localhost","root","","job");

// Specify the query to execute
$sql = "select * from jobseeker_education where JobSeekId='".$ID."'";
// Execute query
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
// Loop through each records 
while($row = mysqli_fetch_array($result))
{
$Degree=$row['Degree'];
$Univ=$row['University'];
$Passing=$row['PassingYear'];
$Per=$row['Percentage'];
?>
                      <tr>
                        <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $Degree;?></strong></div></td>
                        <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $Univ;?></strong></div></td>
                        <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $Passing;?></strong></div></td>
                         <td class="style3"><div align="left" class="style9 style5"><strong><?php echo $Per;?></strong></div></td>
                      </tr>
                      <?php
}
// Retrieve Number of records returned
$records = mysqli_num_rows($result);
?>
                      <tr>
                        <td colspan="4" class="style3"><div align="left" class="style12"><?php echo "Total ".$records." Records"; ?> </div></td>
                      </tr>
                      <?php
// Close the connection
mysqli_close($con);
?>
                    </td>
                  </tr>
                </table>
               
          </div> <!-- /article -->

         </section>
            
        </div> <!-- /content -->



    </div> <!-- /page-in -->
    </div> <!-- /page -->

 
<?php
include "footer.php"
?>



</body>
</html>
