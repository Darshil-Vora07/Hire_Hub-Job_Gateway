<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
<link href="../assets/img/favicon.ico" type="image/x-icon" rel="icon" >
<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
<?php 
include "Header.php"
?>
 
<section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Welcome <?php echo $_SESSION['$UserName_emp'] ;?></h2>
      </div>
    </section><!-- End Breadcrumbs -->               
<?php
$ID=$_SESSION['ID'];
// Establish Connection with Database
$con = mysqli_connect("localhost","root","","job");

$sql = "select * from employer_reg where EmployerId ='".$ID."'  ";
// Execute query
$result = mysqli_query($con,$sql) or die( mysqli_error($con));
// Loop through each records 
$row = mysqli_fetch_array($result)
?>
<section class="inner-page">
<div class="container">
                <table width="100%" border="1" cellspacing="2" cellpadding="2">
                  
                  <tr>
                    <td><strong>Company Name:</strong></td>
                    <td><?php echo $row['CompanyName'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Contact Person:</strong></td>
                    <td><?php echo $row['ContactPerson'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Address:</strong></td>
                    <td><?php echo $row['Address'];?></td>
                  </tr>
                  <tr>
                    <td><strong>City:</strong></td>
                    <td><?php echo $row['City'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Email:</strong></td>
                    <td><?php echo $row['Email'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Mobile:</strong></td>
                    <td><?php echo $row['Mobile'];?></td>
                  </tr>
                  <tr>
                    <td><strong>Area of Work:</strong></td>
                    <td><?php echo $row['Area_Work'];?></td>
                  </tr>
                  <tr>
                    <td><strong>User Name:</strong></td>
                    <td><?php echo $row['UserName'];?></td>
                  </tr>
                  
                  <tr>
                    <td>&nbsp;</td>
                    <td><a href="#" data-toggle="modal" data-target="#Edit">Edit Profile</a></td>
                  </tr>
                </table>
                <?php
                mysqli_close($con);
                ?>
              <p>&nbsp;</p>

                <p class="btn-more box noprint">&nbsp;</p>
</div> 
</section>

           
            
        </div> <!-- /content -->


    </div> <!-- /main -->
    

 
<?php
include "footer.php"
?>

<div class="modal fade" id="Edit" tabindex="-1" role="dialog" aria-labelledby="Edit" aria-hidden="true">
<div class="modal-dialog modal-lg" role="document">
 <div class="modal-content">
 <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit profile</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
</div>
                <form action="UpdateProfile.php" method="post" onSubmit="return validateForm(this,arrFormValidation);" enctype="multipart/form-data" id="form2" style="margin:10px">
                    <div class="form-group"><input type="hidden" id="txtId" name="txtId" value="<?php  echo $ID; ?>">
					<label for="txtName">Company Name</label>
                        <input type="text" name="txtName" id="txtName" class="form-control" id="exampleFormControlInput1" value="<?php echo $row['CompanyName'];?>" placeholder="Company Name"/ required>
                    </div> <div class="form-group">
					<label for="txtPerson">Contact Person</label>
                        <input type="text" name="txtPerson" id="txtPerson" class="form-control" id="exampleFormControlInput1" value="<?php echo $row['ContactPerson'];?>" placeholder="Contact Person"/ required>
                    </div>
                   
                   <div class="form-group">
						<label for="txtAddress">Address</label>
                        <textarea name="txtAddress" id="txtAddress" class="form-control" cols="45" rows="5" placeholder="Address" required><?php echo $row['Address'];?></textarea>
					</div>
                      
					<div class="form-group">
                        <label for="txtCity">City</label>
                        <input type="text" class="form-control" name="txtCity" id="txtCity" value="<?php echo $row['City'];?>" placeholder="City" required />
                     </div>
					<div class="form-group">
                        <label for="txtEmail">Email</label>
                        <input type="email" class="form-control" name="txtEmail" id="txtEmail" value="<?php echo $row['Email'];?>"  placeholder="Email" required />
                     </div>
                    <div class="form-group">
                        <label for="txtMobile">Mobile</label>
                        <input type="tel" minlength="9" maxlength="14" class="form-control" name="txtMobile" id="txtMobile" value="<?php echo $row['Mobile'];?>" placeholder="Phone.no" required />
                     </div>  
                      <div class="form-group">
                        <label for="txtAreaWork">Area of Work</label>
                        <input type="text" class="form-control" name="txtAreaWork" id="txtAreaWork" value="<?php echo $row['Area_Work'];?>" placeholder="Area Of Work" required />
                     </div>
					<div class="form-group">
                        <label for="txtUserName">User Name</label>
                        <input type="text" class="form-control" name="txtUserName" id="txtUserName" value="<?php echo $row['UserName'];?>" placeholder="User Name" required />
                    </div>   
					<div class="form-group">
                        <label for="txtPassword">Password</label>
                        <input type="password" class="form-control" name="txtPassword" id="txtPassword" value="<?php echo $row['Password'];?>" placeholder="Password" required />
                    </div><div class="form-group">
                        <label for="file">Company logo</label>
						<input type="file" class="form-control" accept="image/*" id="file" name="file"/>
                    </div>   
                        <div class="modal-footer">
						  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <input type="submit" name="button2" id="button2" class="btn btn-primary" value="Submit" />
                          </div>
                      
                 </form>
				 <!-- Button trigger modal -->
</div>
</div>
</div>


</body>
</html>
